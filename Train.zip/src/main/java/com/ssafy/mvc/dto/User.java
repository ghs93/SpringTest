package com.ssafy.mvc.dto;

import lombok.Data;

@Data
public class User {
	private String id, pwd;
}
