package com.ssafy.mvc.dto;

import lombok.Data;

@Data
public class FileInfo {
	private String number, saveFolder, saveFile, originFile; 
}
