package com.ssafy.mvc.dto;

import lombok.Data;

@Data
public class Car {
	String number, model, brand;
	int price;
}
